package com.example.Aprendendo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AprendendoApplicationTests {

	@Test
	void contextLoads() {
	}

}
