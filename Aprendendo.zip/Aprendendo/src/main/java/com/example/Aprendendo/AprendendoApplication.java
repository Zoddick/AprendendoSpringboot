package com.example.Aprendendo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AprendendoApplication {

	public static void main(String[] args) {
		SpringApplication.run(AprendendoApplication.class, args);
	}

}
