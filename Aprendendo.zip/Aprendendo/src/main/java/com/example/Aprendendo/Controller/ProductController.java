package com.example.Aprendendo.Controller;

import com.example.Aprendendo.Models.ProductModel;
import com.example.Aprendendo.dtos.ProductRecordDto;
import com.example.Aprendendo.repositories.ProductRepository;
import jakarta.validation.Valid;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;
import java.util.UUID;

import static org.springframework.hateoas.server.mvc.WebMvcLinkBuilder.linkTo;
import static org.springframework.hateoas.server.mvc.WebMvcLinkBuilder.methodOn;

@RestController
public class ProductController {
    @Autowired
    ProductRepository productRepository;
    @PostMapping("/produtos") // metodo HTTP
    public ResponseEntity <ProductModel> salvarProduto (@RequestBody @Valid ProductRecordDto productRecordDto){
     // retorna uma ResponseEntity      nome do metodo    ele recebe como corpo o productrecordDto. o @Valid é pra validar
        var productModel = new ProductModel();
        // iniciando o product model
        BeanUtils.copyProperties(productRecordDto,productModel);
        // convertendo DTO em model ele recebe o dto e converte em model
        return ResponseEntity.status(HttpStatus.CREATED).body(productRepository.save(productModel));
        // aqui ele retorna o status e no corpo do status oq tem no corpo.
    }
    @GetMapping ("/produtos")// outro metodo, agr o get

    public  ResponseEntity <List<ProductModel>> listarTodosProdutos (){
        List <ProductModel> ListaProdutos = productRepository.findAll();
        if (!ListaProdutos.isEmpty()){
            for (ProductModel produto:ListaProdutos) {
            UUID id = produto.getIdProduto();
           produto.add(linkTo(methodOn(ProductController.class).pegarUmProduto(id)).withSelfRel());
            }
        }

        return ResponseEntity.status(HttpStatus.OK).body(ListaProdutos);
    }
    @GetMapping("/produtos/{id}")
    public ResponseEntity <Object> pegarUmProduto(@PathVariable (value = "id")UUID id){
    // pegar um produto so, pelo id dele                    recebendo o id como paramentro


        Optional<ProductModel> produto0 = productRepository.findById(id);
        if (produto0.isEmpty()){
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body("Produto não encontrado");
        }
        produto0.get().add(linkTo(methodOn(ProductController.class).listarTodosProdutos()).withRel("Lista de produtos"));
        return ResponseEntity.status(HttpStatus.OK).body(produto0.get());
    }

    @PutMapping ("/produtos/{id}")
    public ResponseEntity <Object> atualizarProduto (@PathVariable(value = "id") UUID id,
        @RequestBody @Valid ProductRecordDto productRecordDto){

        Optional <ProductModel> produto0 = productRepository.findById(id);
        if (produto0.isEmpty()){
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body("Produto não encontrado");
        }
        var productModel = produto0.get();
        BeanUtils.copyProperties(productRecordDto,productModel);
    return ResponseEntity.status(HttpStatus.OK).body(productRepository.save(productModel));

    }
    @DeleteMapping ("/produtos/{id}")
    public ResponseEntity <Object> removerProduto (@PathVariable (value = "id") UUID id
                                                   ){
        Optional <ProductModel> produto0 = productRepository.findById(id);
        if (produto0.isEmpty()){
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body("Produto não encontrado");
        }
        productRepository.delete(produto0.get());
        return ResponseEntity.status(HttpStatus.OK).body("Produto removido");
    }
}
